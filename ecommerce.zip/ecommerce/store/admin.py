from django.contrib import admin
from .models import *
from django.utils.html import format_html


class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'category', 'image_tag', 'is_featured']
    list_editable=['is_featured']
    search_fields = ['name']
    list_per_page=10
    list_filter = ['name', 'price']

    def image_tag(self, obj):
        return format_html('<img src="{}" width="auto" height="100px" />'.format(obj.image.url))

    image_tag.short_description = 'Product Image Preview'
    readonly_fields = ['image_tag']
class CategoryAdmin(admin.ModelAdmin):
    search_fields = ['name']
    list_filter = ['name']

class CustomerAdmin(admin.ModelAdmin):
    search_fields = ['email']
    list_filter = ['email']


admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(Order)
admin.site.register(Blogpost)
admin.site.register(Contact)

admin.site.site_header = "Syl-Shop Dashboard"
admin.site.site_title = "Syl-Shop"
admin.site.index_title = "Welcome to Syl-Shop Dashboard"

