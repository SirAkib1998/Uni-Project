from email import message
from django.shortcuts import render, redirect
from django.shortcuts import redirect, reverse
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password, check_password
from .middlewares.auth import auth_middleware
from .models import *
      

def homePage(request):
    if request.method == 'POST':
        category_id = request.GET.get('category')
        print(category_id)
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print(request.session['cart'])
        #return redirect('home')
        return redirect(reverse('home') + '?'+ 'category='+category_id)
        

    else:
        products = None
        categories = Category.objects.all()
        category_id = request.GET.get('category')
        if category_id:
            products = Product.objects.filter(category=category_id)
        else:
            products = Product.objects.filter(category=1)
        context = {'products': products, 'categories': categories}
        return render(request, 'store/home.html', context)


def login(request):
    if request.method == "GET":
        return render(request, 'store/login.html')
    else:
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_msg = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['first_name'] = customer.first_name
                return redirect("home")
            else:
                error_msg = "Email or Password is incorrect."
        else:
            error_msg = "Email or Password is incorrect."
        return render(request, 'store/login.html', {'error_msg': error_msg})


def validateCustomer(customer):
    err_msg = None
    if not customer.first_name:
        err_msg = "First Name Required."
    elif len(customer.first_name) < 3:
        err_msg = "First Name must be 3 characters long."
    elif not customer.last_name:
        err_msg = "Last Name Required."
    elif len(customer.last_name) < 3:
        err_msg = "Last Name must be 3 characters long."
    elif not customer.phone:
        err_msg = "Phone is Required."
    elif len(customer.phone) < 10:
        err_msg = "Phone Number must be 10 characters long."
    elif not customer.email:
        err_msg = "Email is Required."
    elif not customer.password:
        err_msg = "Password is Required."
    elif not customer.password2:
        err_msg = "Password 2 is Required."
    elif customer.does_exits():
        err_msg = "User with this email address already registered."
    elif customer.password != customer.password2: 
        err_msg = "Password didn't match."   
    return err_msg


def registerCustomer(request):
    first_name = request.POST.get('firstname')
    last_name = request.POST.get('lastname')
    phone = request.POST.get('phone')
    email = request.POST.get('email')
    password = request.POST.get('password')
    password2 = request.POST.get('password2')

    values = {
        'firstname': first_name,
        'lastname': last_name,
        'phone': phone,
        'email': email,
    }
    customer = Customer(first_name=first_name, last_name=last_name, phone=phone, email=email, password=password, password2=password2)

    err_msg = None
    err_msg = validateCustomer(customer)

    if not err_msg:
        customer.password = make_password(customer.password)
        customer.password2 = make_password(customer.password2)
        customer.save()
        return redirect('home')
    else:
        return render(request, 'store/signup.html', {'error_msg': err_msg, 'values': values})


def signup(request):
    if request.method == 'GET':
        return render(request, 'store/signup.html')
    else:
        return registerCustomer(request)


def logout(request):
    request.session.clear()
    return redirect('home')


def cart(request):
    cart_product_id = list(request.session.get('cart').keys())
    cart_product = Product.get_products_by_id(cart_product_id)
    return render(request, 'store/cart.html', {'cart_product': cart_product})

def checkout(request):
    if request.method == "POST":
        address = request.POST.get("address")
        phone = request.POST.get("phone")
        city=request.POST.get('city', '')
        state=request.POST.get('state', '')
        zip_code=request.POST.get('zip_code', '')
        customer = request.session.get("customer")
        cart = request.session.get("cart")
        products = Product.get_products_by_id(list(cart.keys()))
        for product in products:
            order = Order(customer=Customer(id=customer), product=product, price=product.price, address=address,
                          phone=phone, city=city, state=state, zip_code=zip_code, quantity=cart.get(str(product.id)))
            order.save()

        request.session['cart'] = {}

        return redirect("cart")
    else:
        return render(request, 'store/checkout.html') 


@auth_middleware
def orderpage(request):
    customer = request.session.get('customer')
    order = Order.get_order_by_customer(customer)
    print(order)
    return render(request, 'store/order.html', {'order': order})  

def storehome(request):
    if request.method == 'POST':
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print(request.session['cart'])
        return redirect('storehome')
    else:    
        latest_products = Product.objects.all().order_by('-id')[:6]
        featured_products = Product.objects.filter(is_featured=True).order_by('-id')
        context = {
        'latest_products': latest_products,
        'featured_products': featured_products,
        }
        return render(request,"store/storehome.html", context)

def search(request):
    if request.method == 'POST':
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1
                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print(request.session['cart'])
        #return redirect('search')
        return redirect(reverse('search') + '?'+  request.META['QUERY_STRING'])
    else:    
         query=request.GET['query']
         search_products= Product.objects.filter(name__icontains=query)
         params={'search_products': search_products, 'query': query}
         return render(request, 'store/search.html', params)

def bloghome(request):
    myposts= Blogpost.objects.all()
    print(myposts)
    return render(request, 'store/bloghome.html', {'myposts': myposts})
    #return render(request,"store/bloghome.html")

def blogpost(request, id):
    post = Blogpost.objects.filter(post_id = id)[0]
    print(post)
    return render(request, 'store/blogpost.html',{'post':post})
    #return render(request,"store/blogpost.html")
def contact(request):
    if request.method=="POST":
        print(request)
        name=request.POST.get('name', '')
        email=request.POST.get('email', '')
        phone=request.POST.get('phone', '')
        desc=request.POST.get('desc', '')
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
    return render(request, "store/contact.html")

def about(request):
    return render(request,"store/about.html")